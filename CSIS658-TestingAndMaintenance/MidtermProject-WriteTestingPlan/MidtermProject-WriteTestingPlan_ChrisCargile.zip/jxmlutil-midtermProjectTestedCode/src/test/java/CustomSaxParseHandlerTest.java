import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

import jxmutil.utility.CustomSaxParseHandler;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;
/**
 * this class tests jxmlutil's CustomSaxParseHandler
 * and all the class' methods using 100% statement & branch coverage
 * @author Chris Cargile
 * @since 3/30/2014
 */
public class CustomSaxParseHandlerTest {
	CustomSaxParseHandler customSaxParseHandler;
	DefaultMutableTreeNode defaultMutableTreeNode;
	JTree jTree;
	
	@Before
	public void setUp() throws Exception {
		defaultMutableTreeNode = new DefaultMutableTreeNode();
		jTree = new JTree();
		customSaxParseHandler = new CustomSaxParseHandler(defaultMutableTreeNode,jTree);	
		
	}
	@Test
	public void testStartElement() throws SAXException{
		String uri, localName,tagName;
		uri = "hi"; 
		localName = "hi2"; 
		tagName = "hi3";
		AttributesImpl attr = new AttributesImpl();
		attr.addAttribute("", "", "", "", "");
		customSaxParseHandler.startElement(uri, localName, tagName, attr);
	}
	@Test
	public void testSkippedEntity() throws SAXException{
		customSaxParseHandler.skippedEntity(null);
	}
	@Test
	public void testStartDocument() throws SAXException{
		customSaxParseHandler.startDocument();
	}
	@Test
	public void testCharacters() throws SAXException{
		customSaxParseHandler.characters(("").toCharArray(), 0, 0);
		customSaxParseHandler.characters(("test").toCharArray(), 0, 3);
	}
	@Test
	public void testEndElement() throws SAXException{
		customSaxParseHandler.endElement("","","");
	}
	@Test
	public void testEndDocument() throws SAXException{
		customSaxParseHandler.endDocument();
	}
	@Test
	public void testExpandAll() throws SAXException{
		jTree.add(new JTextField());
		customSaxParseHandler.expandAll(jTree);
	}
}
