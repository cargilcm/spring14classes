import java.io.File;

import jxmutil.utility.FolderFileFilter;

import org.junit.Before;
import org.junit.Test;
/**
 * this class tests jxmlutil's FolderFileFilter
 * and all the class' methods (100% statement & branch coverage)
 * @author Chris Cargile
 * @since 3/30/2014
 */public class FolderFileFilterTest {
	
	// instance variables for use in setUp()
	FolderFileFilter folderFileFilter;
	
	@Before
	public void setUp() throws Exception {
		folderFileFilter = new FolderFileFilter();
	}

	@Test 
	public void testAccept() {
		folderFileFilter.accept(new File(""));
	}
	@Test 
	public void testGetDescription() {
		folderFileFilter.getDescription();
	}
}
