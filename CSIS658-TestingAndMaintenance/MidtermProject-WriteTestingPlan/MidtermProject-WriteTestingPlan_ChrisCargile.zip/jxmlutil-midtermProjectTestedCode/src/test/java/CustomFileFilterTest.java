import java.io.File;
import jxmutil.utility.CustomFileFilter;
import org.junit.Before;
import org.junit.Test;
/**
 * this class tests jxmlutil's CustomFileFilter
 * and all the class' methods (100% statement & branch coverage)
 * @author Chris Cargile
 * @since 3/30/2014
 */
public class CustomFileFilterTest {

	// instance variables for testing's setUp()
	CustomFileFilter customFileFilter;
	File f;
	
	@Before
	public void setUp() throws Exception {
		customFileFilter = new CustomFileFilter();
		f = new File("test.xml");
		System.out.println("test xml file created is on local disk at: "+f.getAbsolutePath());
	}

	/** per the bottom of the webpage here:
	 * https://github.com/cobertura/cobertura/wiki/Line-Coverage-Explained,
	 * expected behavior reported by cobertura is unknown for 'special-if' case (Scenario#6).
	 * Whereas, customFileFilter.accept() returns a value computed from compound evaluation,
	 * and cobertura reports '1', this seems reasonable to me..after all it's not all-paths right?
	 */
	@Test
	public void testAccept() {
		String fileTests[] = {"test.xml",System.getProperty("user.home"),"test.xsl","text.xsd", ""};
		for(int i=0;i<fileTests.length;i++){
			f=new File(fileTests[i]);
			customFileFilter.accept(f);
		}
	}
	
	@Test
	public void testDescription() {
		customFileFilter.getDescription();
	}
}
