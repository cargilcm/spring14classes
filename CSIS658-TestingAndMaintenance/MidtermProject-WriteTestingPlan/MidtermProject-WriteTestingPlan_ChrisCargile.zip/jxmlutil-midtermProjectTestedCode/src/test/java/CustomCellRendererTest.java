import javax.swing.JTextField;
import javax.swing.JTree;

import jxmutil.utility.CustomCellRenderer;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * this class tests jxmlutil's CustomFileFilter
 * and all the class' methods (100% statement & branch coverage)
 * @author Chris Cargile
 * @since 3/30/2014
 */
public class CustomCellRendererTest {
	//instance var's for testing's setUp()
	CustomCellRenderer customCellRenderer;
	JTree tree;
	Object value;
	boolean selected,expanded,leaf,hasFocus;
	int row;
	
	@Before
	public void setUp() {
		customCellRenderer = new CustomCellRenderer();
		tree = new JTree();
		//tree.add(new JTextField());
		value = "helloUnnecessarily-ValuedStringLiteral";
		selected=true;
		expanded=true;
		leaf=true;
		hasFocus=true;
		row = 2;
	}
	
	@Test
	public void testGetTreeCellRendererComponenet() {
		customCellRenderer.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);
		leaf=false;
		customCellRenderer.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);
	}
}
