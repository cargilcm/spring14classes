import java.io.File;
import java.io.IOException;

import jxmutil.utility.XmlFilenameFilter;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
/**
 * this class tests jxmlutil's XmlFilenameFilter
 * and all the class' methods (100% statement & branch coverage)
 * @author Chris Cargile
 * @since 3/30/2014
 */
public class XmlFilenameFilterTest {
	XmlFilenameFilter xmlFilenameFilter;
	
	@Before
	public void setUp() throws Exception {
		xmlFilenameFilter = new XmlFilenameFilter();
	}

	@Test
	public void testAccept() throws IOException {
		String user = System.getProperty("user.home");
		File f = new File(user.concat("test.xml"));
		xmlFilenameFilter.accept(f,"");
	}

}
