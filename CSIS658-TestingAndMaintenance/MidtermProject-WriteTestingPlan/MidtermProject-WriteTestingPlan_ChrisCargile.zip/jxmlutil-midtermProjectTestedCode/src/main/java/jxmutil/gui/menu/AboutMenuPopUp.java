package jxmutil.gui.menu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

/**
 * The pop-up window showed when the user click on the "About --> Info" entry in the menu bar
 *
 */
public class AboutMenuPopUp extends JDialog implements ActionListener {

	
	private static final long serialVersionUID = 1L;
	
	private JTabbedPane tabbedPane;
	JButton closeButton;
	/**
	 * Constructor
	 */
	public AboutMenuPopUp() {	
		
			this.setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));			
			
			tabbedPane = new JTabbedPane(); 
			
			tabbedPane.addTab("General Info", new JPanel());			
			tabbedPane.addTab("Application License", new JPanel());
			tabbedPane.addTab("Third Part License", new JPanel());
			
			this.add(tabbedPane);
	
		    //---- The Close button that close the pop up window
		    closeButton = new JButton("Close");
		    closeButton.addActionListener(this);

		    //---------------------
	       
	        this.add(closeButton);

	        //set the dialog as a modal window
	        this.setModalityType(ModalityType.APPLICATION_MODAL);

	        this.setTitle("About");
	        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	        this.setLocationRelativeTo(null);
	        this.setSize(700, 550);    
	        
	        this.setVisible(true);		
	}
	public void actionPerformed(ActionEvent evt){
		    dispose();
	}
	public void doClose(){
		closeButton.doClick();
	}
}
