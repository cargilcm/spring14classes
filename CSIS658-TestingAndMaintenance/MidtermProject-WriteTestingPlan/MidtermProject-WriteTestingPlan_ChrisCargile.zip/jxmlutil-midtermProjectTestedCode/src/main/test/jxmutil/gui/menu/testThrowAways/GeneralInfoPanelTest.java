package jxmutil.gui.menu.testThrowAways;


import static org.junit.Assert.assertTrue;
import jxmutil.gui.menu.GeneralinfoPanel;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class GeneralInfoPanelTest {
	public GeneralinfoPanel generalInfoPanel;
	@Before
	public void setUp(){
		generalInfoPanel = new GeneralinfoPanel();
	}
	@After
	public void tearDown(){
		generalInfoPanel.setVisible(false);
	}
	@Test
	public void testGeneralInfoPanel(){
		assertTrue(generalInfoPanel!=null);
	}
}
