package jxmutil.gui.menu.testThrowAways;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import org.junit.Test;

public class FolderFileFilterTest {
	String s="";
	@Test
	public void testFolderFileFilter() {
		assertNotNull(s);
	}

	@Test
	public void testAcceptFile() {
		assertNotNull(s);
	}

	@Test
	public void testGetDescription() {
		assertNotNull(s);
	}

}
