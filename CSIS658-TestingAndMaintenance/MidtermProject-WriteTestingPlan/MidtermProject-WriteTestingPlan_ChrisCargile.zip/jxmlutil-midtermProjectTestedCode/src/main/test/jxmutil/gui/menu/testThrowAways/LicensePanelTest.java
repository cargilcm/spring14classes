package jxmutil.gui.menu.testThrowAways;

import static org.junit.Assert.assertTrue;
import jxmutil.gui.menu.LicensePanel;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;



public class LicensePanelTest {
	LicensePanel licensePanel;
	@Before
	public void setUp(){
		licensePanel = new LicensePanel();
	}
	@After
	public void tearDown(){
		licensePanel.setVisible(false);
	}
	
	@Test
	public void testLicensePanel(){
		assertTrue(licensePanel!=null);
	}
}
