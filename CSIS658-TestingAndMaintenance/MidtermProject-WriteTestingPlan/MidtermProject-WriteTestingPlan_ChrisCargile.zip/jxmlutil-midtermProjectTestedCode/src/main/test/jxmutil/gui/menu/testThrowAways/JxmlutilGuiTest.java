package jxmutil.gui.menu.testThrowAways;
import static org.junit.Assert.assertNotNull;

import javax.swing.JFrame;
import javax.swing.UIManager;

import jxmutil.gui.JxmlutilGui;

import org.junit.Test;

public class JxmlutilGuiTest {
	
	@Test
	public void testJxmlutilGui() {
		JxmlutilGui mainGui = new JxmlutilGui();
		JFrame rootFrame = mainGui.getRootFrame();
		assertNotNull(rootFrame.getTitle());
	}
}
