package jxmutil.gui.menu.testThrowAways;

import static org.junit.Assert.*;

import org.junit.Test;

public class XsltPanelTest {
	String s= "";
	@Test
	public void testXsltPanel() {
		assertNotNull(s);
	}

	@Test
	public void testActionPerformed() {
		//fail("Not yet implemented"); // TODO
		assertNotNull(s);
	}

	@Test
	public void testGetSourceXMLfileTextField() {
//		fail("Not yet implemented"); // TODO
		assertNotNull(s);
	}

	@Test
	public void testSetSourceXMLfileTextField() {
//		fail("Not yet implemented"); // TODO
		assertNotNull(s);
	}

	@Test
	public void testGetPathXslFile() {
//		fail("Not yet implemented"); // TODO
		assertNotNull(s);
	}

	@Test
	public void testSetPathXslFile() {
//		fail("Not yet implemented"); // TODO
		assertNotNull(s);
	}

}
