package jxmutil.gui.menu.testThrowAways;


import static org.junit.Assert.assertTrue;
import jxmutil.gui.menu.ThirdPartLicense;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;



public class ThirdPartLicenseTest {
	
	private ThirdPartLicense thirdPartLicense;
	
	@Before
	public void setUp() throws Exception {
		thirdPartLicense = new ThirdPartLicense();
	}
	
	@After
	public void tearDown(){
		thirdPartLicense.setVisible(false);
	}
	
	@Test
	public void testThirdPartLicense(){
		assertTrue(thirdPartLicense!=null);
	}
}
