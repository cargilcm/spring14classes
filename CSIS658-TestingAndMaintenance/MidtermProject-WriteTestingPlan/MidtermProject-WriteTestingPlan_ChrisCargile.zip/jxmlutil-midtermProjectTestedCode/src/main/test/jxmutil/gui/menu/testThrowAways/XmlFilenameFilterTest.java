package jxmutil.gui.menu.testThrowAways;

import static org.junit.Assert.*;

import org.junit.Test;

public class XmlFilenameFilterTest {

	@Test
	public void testAccept() {
		//fail("Not yet implemented"); // TODO
	}

}
