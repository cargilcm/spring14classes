package jxmutil.gui.menu.testThrowAways;

import static org.junit.Assert.*;

import org.junit.Test;

public class CustomSaxParseHandlerTest {

	String s="";
	
	@Test
	public void testStartDocument() {
		assertNotNull(s);
	}

	@Test
	public void testEndDocument() {
		assertNotNull(s);
	}

	@Test
	public void testCharacters() {
		assertNotNull(s);
	}

	@Test
	public void testCustomSaxParseHandler() {
		assertNotNull(s);
	}

	@Test
	public void testStartElementStringStringStringAttributes() {
		assertNotNull(s);
	}

	@Test
	public void testSkippedEntityString() {
		assertNotNull(s);
	}

	@Test
	public void testEndElementStringStringString() {
		assertNotNull(s);
	}

	@Test
	public void testExpandAll() {
		assertNotNull(s);
	}

}
