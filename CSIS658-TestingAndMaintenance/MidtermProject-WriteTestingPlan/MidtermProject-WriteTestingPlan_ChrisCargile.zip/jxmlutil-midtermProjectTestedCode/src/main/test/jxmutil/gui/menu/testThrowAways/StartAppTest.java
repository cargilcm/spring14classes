package jxmutil.gui.menu.testThrowAways;
import static org.junit.Assert.assertTrue;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import junit.framework.Assert;
import jxmutil.init.StartApp;

import org.junit.Before;
import org.junit.Test;
public class StartAppTest {

	StartApp startApp;
	Thread threads[];
	StackTraceElement stackTrace[][];
	StackTraceElement stackTrace2[];
	
	@Before
	public void setUp() throws Exception {
		startApp = new StartApp();
		}

	@Test
	public void testMain() {
		startApp.main(null);
		System.setProperty("javax.xml.transform.TransformerFactory","org.apache.xalan.processor.TransformerFactoryImpl");
		assertTrue(System.getProperty("javax.xml.xpath.XPathFactory").equals("org.apache.xpath.jaxp.XPathFactoryImpl"));
		assertTrue(System.getProperty("javax.xml.parsers.DocumentBuilderFactory").equals("org.apache.xerces.jaxp.DocumentBuilderFactoryImpl"));
		assertTrue(System.getProperty("javax.xml.parsers.SAXParserFactory").equals("org.apache.xerces.jaxp.SAXParserFactoryImpl"));
		assertTrue(System.getProperty("javax.xml.validation.SchemaFactory:http://www.w3.org/2001/XMLSchema").equals("org.apache.xerces.jaxp.validation.XMLSchemaFactory"));
		//System.out.println(System.getProperties());
		threads = new Thread[java.lang.Thread.activeCount()];
		java.lang.Thread.enumerate(threads);
		Assert.assertTrue(threads.length>=1);
//		for(Thread t: threads){
//			stackTrace2 = t.getStackTrace();
//			for(StackTraceElement el:stackTrace2)
//				System.out.println(el);
//		}


		Map<Thread,StackTraceElement[]> mapping = java.lang.Thread.getAllStackTraces();
		Set set = mapping.entrySet();
		Iterator it = set.iterator();
		boolean Runs = false;
		while(it.hasNext()){
			Entry<Thread,StackTraceElement[]> entry = (Entry<Thread,StackTraceElement[]>)it.next();
			if(entry!=null){
				StackTraceElement el[] = (StackTraceElement[])entry.getValue();
				for(StackTraceElement elEl: el){
//					if(elEl.getMethodName().contains("run")){
//						System.out.print(elEl+"\t");
//						System.out.print(elEl.getMethodName()+"\t");
//						System.out.println(elEl.getFileName());
//					}
					if(elEl.toString().contains("StartApp"))
						Runs=true;
				}
			}
		}
		assertTrue(Runs);
	}
}
