package jxmutil.gui.menu.testThrowAways;

import static org.junit.Assert.*;

import org.junit.Test;

public class CustomFileFilterTest {

	String s="";
	@Test
	public void testCustomFileFilter() {
		assertNotNull(s);
	}

	@Test
	public void testAcceptFile() {
		assertNotNull(s);
	}

	@Test
	public void testGetDescription() {
		assertNotNull(s);
	}

}
