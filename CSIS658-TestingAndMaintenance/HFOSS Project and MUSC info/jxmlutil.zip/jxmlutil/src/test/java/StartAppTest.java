

import jxmutil.init.StartApp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class StartAppTest {

	StartApp startApp;
	
	@Before
	public void setUp() throws Exception {
		startApp = new StartApp();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testMain() {
		
	}

}
