
import static org.junit.Assert.*;

import org.junit.Test;

public class CustomFileFilterTest {

	@Test
	public void testCustomFileFilter() {

	}

	@Test
	public void testAcceptFile() {

	}

	@Test
	public void testGetDescription() {

	}

}
