
import static org.junit.Assert.*;

import org.junit.Test;

public class XsltPanelTest {

	@Test
	public void testXsltPanel() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testActionPerformed() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetSourceXMLfileTextField() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetSourceXMLfileTextField() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetPathXslFile() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetPathXslFile() {
		fail("Not yet implemented"); // TODO
	}

}
