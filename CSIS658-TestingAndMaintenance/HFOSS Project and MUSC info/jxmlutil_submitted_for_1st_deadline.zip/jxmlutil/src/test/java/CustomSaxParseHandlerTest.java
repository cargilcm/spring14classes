
import static org.junit.Assert.*;

import org.junit.Test;

public class CustomSaxParseHandlerTest {

	@Test
	public void testStartDocument() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testEndDocument() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCharacters() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCustomSaxParseHandler() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testStartElementStringStringStringAttributes() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSkippedEntityString() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testEndElementStringStringString() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testExpandAll() {
		fail("Not yet implemented"); // TODO
	}

}
