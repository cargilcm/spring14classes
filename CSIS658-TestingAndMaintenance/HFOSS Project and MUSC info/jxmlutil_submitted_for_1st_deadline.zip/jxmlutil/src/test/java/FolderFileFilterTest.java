
import static org.junit.Assert.fail;

import org.junit.Test;

public class FolderFileFilterTest {

	@Test
	public void testFolderFileFilter() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAcceptFile() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetDescription() {
		fail("Not yet implemented"); // TODO
	}

}
