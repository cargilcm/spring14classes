import c2.framework.*;

public class Clock extends ComponentThread{
	public Clock(){
		super.create("clock", FIFOPort.class);
	}
	
	public void start(){
		super.start();
		
		Thread clockThread = new Thread(){
			public void run(){
				//Repeat while the application runs
				while(true){
					//Wait for five seconds
					try{
						Thread.sleep(5000);
					}
					catch(InterruptedException ie){}
					
					//Send out a tick notification
					Notification n = new Notification("clockTick");
					send(n);
				}
			}
		};
		clockThread.start();
	}
	
	protected void handle(Notification n){
		//This component does not handle notifications
	}
	
	protected void handle(Request r){
		//This component does not handle requests
	}
}
