import c2.framework.*;

public class GameState extends ComponentThread{
	public GameState(){
		super.create("gameState", FIFOPort.class);
	}
	
	//Initialize values
	int altitude = 1000;
	int fuel = 500;
	int velocity = 70;
	int time = 0;
	int burnRate = 0;
	boolean landedSafely = false;
	
	protected void handle(Request r){
		if(r.name().equals("updateGameState")){
			//Update the internal game state
			if(r.hasParameter("altitude")){
				this.altitude = ((Integer)r.getParameter("altitude")).intValue();
			}
			if(r.hasParameter("fuel")){
				this.fuel = ((Integer)r.getParameter("fuel")).intValue();
			}
			if(r.hasParameter("velocity")){
				this.velocity = ((Integer)r.getParameter("velocity")).intValue();
			}
			if(r.hasParameter("time")){
				this.time = ((Integer)r.getParameter("time")).intValue();
			}
			if(r.hasParameter("burnRate")){
				this.burnRate = ((Integer)r.getParameter("burnRate")).intValue();
			}
			if(r.hasParameter("landedSafely")){
				this.landedSafely = ((Boolean)r.getParameter("landedSafely")).booleanValue();
			}
			
			Notification n = createStateNotification();
			send(n);
		}
		else if(r.name().equals("getGameState")){
			Notification n = createStateNotification();
			send(n);
		}
	}
	
	protected Notification createStateNotification(){
		Notification n = new Notification("gameState");
		n.addParameter("altitude", altitude);
		n.addParameter("fuel", fuel);
		n.addParameter("velocity", velocity);
		n.addParameter("time", time);
		n.addParameter("burnRate", burnRate);
		n.addParameter("landedSafely", landedSafely);
		return n;
	}
	
	protected void handle(Notification n){
		//This component does not handle notifications
	}
}
