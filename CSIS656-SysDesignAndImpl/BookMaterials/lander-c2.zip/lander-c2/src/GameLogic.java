import c2.framework.*;

public class GameLogic extends ComponentThread{
	public GameLogic(){
		super.create("gameLogic", FIFOPort.class);
	}

	//Game constants
	final int GRAVITY = 2;
	
	//Internal state values for computation
	int altitude = 0;
	int fuel = 0;
	int velocity = 0;
	int time = 0;
	int burnRate = 0;
	
	public void start(){
		super.start();
		Request r = new Request("getGameState");
		send(r);
	}
	
	protected void handle(Notification n){
		if(n.name().equals("gameState")){
			if(n.hasParameter("altitude")){
				this.altitude = ((Integer)n.getParameter("altitude")).intValue();
			}
			if(n.hasParameter("fuel")){
				this.fuel = ((Integer)n.getParameter("fuel")).intValue();
			}
			if(n.hasParameter("velocity")){
				this.velocity = ((Integer)n.getParameter("velocity")).intValue();
			}
			if(n.hasParameter("time")){
				this.time = ((Integer)n.getParameter("time")).intValue();
			}
			if(n.hasParameter("burnRate")){
				this.burnRate = ((Integer)n.getParameter("burnRate")).intValue();
				if(this.burnRate < 0) System.exit(1);
			}
		}
		else if(n.name().equals("clockTick")){
			//Calculate new lander state values
			int actualBurnRate = burnRate;
			if(actualBurnRate > fuel){
				actualBurnRate = fuel;
			}
			
			time = time + 1;
			altitude = altitude - velocity;
			velocity = ((velocity + GRAVITY) * 10 - actualBurnRate * 2) / 10;
			fuel = fuel - actualBurnRate;
			
			//Determine if we landed safely
			boolean landedSafely = false;
			if(altitude <= 0){
				altitude = 0;
				if(velocity <= 5){
					landedSafely = true;
				}
			}
			
			Request r = new Request("updateGameState");
			r.addParameter("time", time);
			r.addParameter("altitude", altitude);
			r.addParameter("velocity", velocity);
			r.addParameter("fuel", fuel);
			r.addParameter("landedSafely", landedSafely);
			send(r);
		}
	}
	
	protected void handle(Request r){
		//This component does not handle requests
	}

}
