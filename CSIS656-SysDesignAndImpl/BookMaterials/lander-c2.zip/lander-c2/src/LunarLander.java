import c2.framework.*;

public class LunarLander{

	public static void main(String[] args){
		//Create the Lunar Lander architecture
		Architecture lunarLander = new SimpleArchitecture("LunarLander");
		
		//Create the components
		Component clock = new Clock();
		Component gameState = new GameState();
		Component gameLogic = new GameLogic();
		Component gui = new GUI();
		
		//Create the connectors
		Connector bus = new ConnectorThread("bus");
		
		//Add the components and connectors to the architecture
		lunarLander.addComponent(clock);
		lunarLander.addComponent(gameState);
		lunarLander.addComponent(gameLogic);
		lunarLander.addComponent(gui);
		
		lunarLander.addConnector(bus);
		
		//Create the welds (links) between components and
		//connectors
		lunarLander.weld(clock, bus);
		lunarLander.weld(gameState, bus);
		lunarLander.weld(bus, gameLogic);
		lunarLander.weld(bus, gui);
		
		//Start the application
		lunarLander.start();
	}
}
