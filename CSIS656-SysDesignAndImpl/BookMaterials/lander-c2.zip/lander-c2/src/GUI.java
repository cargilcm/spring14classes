import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import c2.framework.*;

public class GUI extends ComponentThread{
	public GUI(){
		super.create("gui", FIFOPort.class);
	}

	public void start(){
		super.start();
		Thread t = new Thread(){
			public void run(){
				processInput();
			}
		};
		t.start();
	}
	
	public void processInput(){
		System.out.println("Welcome to Lunar Lander");
		try{
			BufferedReader inputReader = new BufferedReader(new InputStreamReader(System.in));
			
			int burnRate = 0;
			do{
				System.out.println("Enter burn rate or <0 to quit:");
				try{
					String burnRateString = inputReader.readLine();
					burnRate = Integer.parseInt(burnRateString);
					
					Request r = new Request("updateGameState");
					r.addParameter("burnRate", burnRate);
					send(r);
				}
				catch(NumberFormatException nfe){
					System.out.println("Invalid burn rate.");
				}
			}while(burnRate >= 0);
			inputReader.close();
		}
		catch(IOException ioe){
			ioe.printStackTrace();
		}
	}
	
	protected void handle(Notification n){
		if(n.name().equals("gameState")){
			System.out.println();
			System.out.println("New game state:");
			if(n.hasParameter("altitude")){
				System.out.println("  Altitude: " + n.getParameter("altitude"));
			}
			if(n.hasParameter("fuel")){
				System.out.println("  Fuel: " + n.getParameter("fuel"));
			}
			if(n.hasParameter("velocity")){
				System.out.println("  Velocity: " + n.getParameter("velocity"));
			}
			if(n.hasParameter("time")){
				System.out.println("  Time: " + n.getParameter("time"));
			}
			if(n.hasParameter("burnRate")){
				System.out.println("  Current burn rate: " + n.getParameter("burnRate"));
			}
			
			if(n.hasParameter("altitude")){
				int altitude = ((Integer)n.getParameter("altitude")).intValue();
				if(altitude <= 0){
					boolean landedSafely = ((Boolean)n.getParameter("landedSafely")).booleanValue();
					if(landedSafely){
						System.out.println("You have landed safely.");
					}
					else{
						System.out.println("You have crashed.");
					}
					System.exit(0);
				}
			}
		}
	}
	
	protected void handle(Request r){
		//This component does not handle requests
	}
}
