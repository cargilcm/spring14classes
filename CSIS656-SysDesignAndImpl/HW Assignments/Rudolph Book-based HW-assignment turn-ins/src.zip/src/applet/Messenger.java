package applet;

import java.applet.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

import netscape.javascript.JSObject;


public class Messenger extends Applet implements ActionListener{
	/**
	 * Enables User to type in text and click send
	 */
	TextField tMesseng;
	Button bSend;
	public void init()
	{
		tMesseng =new TextField(20);
		bSend = new Button("Send");
		add(tMesseng);
		add(bSend);
		bSend.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e)
	{
		String at = e.getActionCommand();
		String message;
		if (at.equals("Send"))
		{
			JSObject window = JSObject.getWindow(this);
			message = tMesseng.getText();
			window.setMember("message", message);
			window.eval("displayMessage()");
		}
		
	}

}
