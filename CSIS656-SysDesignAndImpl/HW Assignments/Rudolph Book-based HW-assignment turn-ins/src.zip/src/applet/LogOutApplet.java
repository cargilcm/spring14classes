/**
 * This applet will log the user out of the server.
 */

package applet;

import java.applet.Applet;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import netscape.javascript.*;


public class LogOutApplet extends Applet implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8202610004895117997L;

	public void init(){
		Button logOutButton = new Button("Log Out");
		logOutButton.addActionListener(this);
		add(logOutButton);
	}
	
	public void actionPerformed(ActionEvent e){
		//this function will access the server and log out
		Button checkButton = (Button)e.getSource();
		
		if(checkButton.getLabel() == "Log Out"){
			JSObject window = JSObject.getWindow(this);
			window.eval("disconnect()");
			//access server and log out
			
		}
	}
}
