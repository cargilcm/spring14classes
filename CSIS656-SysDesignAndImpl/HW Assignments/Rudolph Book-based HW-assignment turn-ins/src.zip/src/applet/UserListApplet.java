/**
 * This applet will show the available users that are connected
 * to the server.
 */
package applet;

import java.applet.Applet;
import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JScrollPane;

import netscape.javascript.JSObject;

public class UserListApplet extends Applet{ //implements ActionListener{
	
	private JScrollPane scrollPane;
	private JList userList;
	private DefaultListModel model;
	
	//these lists will be used to store the values just in 
	//case they are needed later?
	private List storedUserList;
	private List storedIPList;
	
	public void init(){
		/**
		 * Test Data Code
		 */
		/**
		final String[] data1 = {"hello","hello2"};
		
		final String[] data2 = {"hello3","hello4"};
		
		Button b1 = new Button("array1");
		Button b2 = new Button("array2");
		b1.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				DefaultListModel Model1 = (DefaultListModel) userList.getModel();
				for(int i = 0; i< data1.length; i++){
					Model1.addElement(data1[i]);
				}
			}
		});
		b2.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				DefaultListModel Model2 = (DefaultListModel) userList.getModel();
				for(int i = 0; i< data2.length; i++){
					Model2.addElement(data2[i]);
				}
			}
		});
		
		**/
		/**
		 * End Test Data Code
		 */
		userList = new JList();
		model = new DefaultListModel();		
		userList.setModel(model);
		scrollPane = new JScrollPane(userList);

		add(scrollPane);
		//add(b1);
		//add(b2);
	}
	

	public void updateUserList(String[] data){		
		DefaultListModel tempModel = (DefaultListModel) userList.getModel();
		tempModel.clear();

		for(int i = 0; i< data.length; i++){
			tempModel.addElement(data[i]);
		}
		//userList = new JList<String>(getUserList());
	}
}
