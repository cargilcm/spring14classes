
package applet;



import java.applet.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;

import netscape.javascript.JSObject;


//import netscape.javascript.JSObject;

public class login_page extends Applet implements ActionListener
{
	
	private static final long serialVersionUID = 1L;
	
	String Uname = "";
	String Pswd ="";
	Label lUname, lPswd;
	TextField tUname, tPswd;
	Button blogin;
	String str;
	//for socket connection
	Socket localsocket;
	PrintWriter out;
	BufferedReader in;
	
	
	public void init()
	{
		lUname = new Label("UserName:");
		lPswd = new Label("Password:");
		tUname = new TextField(10);
		tPswd = new TextField(10);
		//tPswd.setEchoCharacter("*");
		blogin = new Button("Login");
		add(lUname);
		add(tUname);
		add(lPswd);
		add(tPswd);		
		add (blogin);
		blogin.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent e)
	{
		Uname = tUname.getText();
		Pswd = tPswd.getText();
		
		String s = e.getActionCommand();
		if (s.equals("Login"))
		{
			//JSObject window = JSObject.getWindow(this);
			//boolean loginValid = false;
			Uname = tUname.getText();
			Pswd = tPswd.getText();
			if (!Uname.equals("") && !Pswd.equals(""))
			{
				JSObject window = JSObject.getWindow(this);
				window.setMember("user_id", Uname);
				window.setMember("password", Pswd);
				window.eval("login();");
				
				
			}
			else
			{
			// if any of the field is null - throws error message to enter valid credentials
				System.out.println("Enter Valid Username and Password");
				repaint();
			}
			
		
		//window.eval("login()");
		}
			
	}
	
}

