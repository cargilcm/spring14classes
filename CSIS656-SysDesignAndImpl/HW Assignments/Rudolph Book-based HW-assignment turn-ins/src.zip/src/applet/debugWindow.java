package applet;

import java.applet.Applet;
import java.awt.GridLayout;

import javax.swing.JTextArea;

public class debugWindow extends Applet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4613495282990763650L;
	private JTextArea bulletinBoard;

	public void init() {
	bulletinBoard = new JTextArea(10, 25);
	bulletinBoard.setAutoscrolls(true);
	this.setLayout(new GridLayout());
	this.add(bulletinBoard);
	}
	
	public void logMsg(String s) {
		bulletinBoard.append(s+"\n");
		bulletinBoard.repaint();
	}
}
