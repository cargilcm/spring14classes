package SampleCode;

import java.applet.Applet;
import java.awt.Button;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import netscape.javascript.JSObject;


public class TestApplet extends Applet implements ActionListener {
	private Label lUname;
	private Label lPswd;
	private TextField tUname;
	private TextField tPswd;
	private Button blogin;
	private String Uname;
	private String Pswd;
	private String logb;
	public void init()
	{
		lUname = new Label("UserName:");
		lPswd = new Label("Password:");
		tUname = new TextField(20);
		tPswd = new TextField(10);
		blogin = new Button("Login");
		add(lUname);
		add(lPswd);
		add(tUname);
		add(tPswd);		
		add (blogin);
		
		blogin.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent e)
	{
		String s = e.getActionCommand();
		JSObject window = JSObject.getWindow(this);
		//window.eval("displayMessage()");
		
		if (s.equals("Login"))
		{
			Uname = tUname.getText();
			Pswd = tPswd.getText();
			String arg =  Uname + ", " + Pswd ;
			window.setMember("string", arg);
			window.eval("displayMessage()");
			if (Uname != "" && Pswd!="")
			{
				/**
				 * calls server and sends the login info and server will return boolean if login pass or fail
				 */
				if (logb=="False")
				{
					System.out.println("Login Failed - Enter Valid Username and Password");
					repaint(); }
			}
			else{
			// if any of the field is null - throws error message to enter valid credentials
				System.out.println("Enter Valid Username and Password");
				repaint();}
		} else {
			System.out.println("Enter Valid Username and Password");
			repaint();
		}
			
	}
}
