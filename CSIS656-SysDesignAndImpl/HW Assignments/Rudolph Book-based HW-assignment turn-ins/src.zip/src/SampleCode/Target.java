package SampleCode;


import java.applet.*;
import java.awt.*;


public class Target extends Applet {
	private TextArea textArea;

	public void init() {
		textArea = new TextArea(5, 20);
		add(textArea);
		//ScrollPane scrollPane = new ScrollPane(); 
		textArea.setEditable(false);
		textArea.setText("Begin Transmission: \n");
		repaint();
	}
	
	public void updateText(String s) {
		textArea.append(s+"\n");
		repaint();
	}
}
