package P2PConnector;

import server.RegistryServer;
import applet.ServerConnector;
//import applet.ServerConnectorWrapper;

public class serverTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ServerConnectorWrapper s = new ServerConnectorWrapper();
		
		RegistryServer s1 = new RegistryServer();
		
		//s.login("nick", "password");
		while(true){}
		
	}

}
