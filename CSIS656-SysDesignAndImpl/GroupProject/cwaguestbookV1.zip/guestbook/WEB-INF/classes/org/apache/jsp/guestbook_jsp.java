package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.List;
import com.google.appengine.api.users.User;
import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

public final class guestbook_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n\n\n\n\n\n\n\n\n\n\n\n\n<html>\n  <head>\n    <link type=\"text/css\" rel=\"stylesheet\" href=\"/stylesheets/main.css\" />\n  </head>\n\n  <body>\n\n");

    String guestbookName = request.getParameter("guestbookName");
    if (guestbookName == null) {
        guestbookName = "default";
    }
    UserService userService = UserServiceFactory.getUserService();
    User user = userService.getCurrentUser();
    if (user != null) {

      out.write("\n<p>Hello, ");
      out.print( user.getNickname() );
      out.write("! (You can\n<a href=\"");
      out.print( userService.createLogoutURL(request.getRequestURI()) );
      out.write("\">sign out</a>.)</p>\n");

    } else {

      out.write("\n<p>Hello!\n<a href=\"");
      out.print( userService.createLoginURL(request.getRequestURI()) );
      out.write("\">Sign in</a>\nto include your name with greetings you post.</p>\n");

    }

      out.write('\n');
      out.write('\n');

    DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
    Key guestbookKey = KeyFactory.createKey("Guestbook", guestbookName);
    // Run an ancestor query to ensure we see the most up-to-date
    // view of the Greetings belonging to the selected Guestbook.
    Query query = new Query("Greeting", guestbookKey).addSort("date", Query.SortDirection.DESCENDING);
    List<Entity> greetings = datastore.prepare(query).asList(FetchOptions.Builder.withLimit(5));
    if (greetings.isEmpty()) {
        
      out.write("\n        <p>Guestbook '");
      out.print( guestbookName );
      out.write("' has no messages.</p>\n        ");

    } else {
        
      out.write("\n        <p>Messages in Guestbook '");
      out.print( guestbookName );
      out.write("'.</p>\n        ");

        for (Entity greeting : greetings) {
            if (greeting.getProperty("user") == null) {
                
      out.write("\n                <p>An anonymous person wrote:</p>\n                ");

            } else {
                
      out.write("\n                <p><b>");
      out.print( ((User) greeting.getProperty("user")).getNickname() );
      out.write("</b> wrote:</p>\n                ");

            }
            
      out.write("\n            <blockquote>");
      out.print( greeting.getProperty("content") );
      out.write("</blockquote>\n            ");

        }
    }

      out.write("\n\n    <form action=\"/sign\" method=\"post\">\n      <div><textarea name=\"content\" rows=\"3\" cols=\"60\"></textarea></div>\n      <div><input type=\"submit\" value=\"Post Greeting\" /></div>\n      <input type=\"hidden\" name=\"guestbookName\" value=\"");
      out.print( guestbookName );
      out.write("\"/>\n    </form>\n\n    <form action=\"/guestbook.jsp\" method=\"get\">\n      <div><input type=\"text\" name=\"guestbookName\" value=\"");
      out.print( guestbookName );
      out.write("\"/></div>\n      <div><input type=\"submit\" value=\"Switch Guestbook\" /></div>\n    </form>\n\n  </body>\n</html>\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
