package applet;






import java.applet.Applet;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JTextField;

import netscape.javascript.JSException;
import netscape.javascript.JSObject;



public class Receiver extends Applet implements ActionListener {
	int ctr=0;
	JTextField ctrLbl;
	TextArea bulletinBoard;
	
	public void init(){
		bulletinBoard = new TextArea();
		ctrLbl = new JTextField(20);
		ctrLbl.setText("hello receiver");
		this.add(ctrLbl);
		
		JButton button = new JButton();
		button.setText("Increment");
		button.addActionListener(this);
		this.add(button);
	}
	public void actionPerformed(ActionEvent e)
	{
		JSObject window = null;
		try {
		    incrementCounter();
		    
		    window = (JSObject) JSObject.getWindow(this);
		    ctrLbl.setText(getCount());
		    window.eval("writeMsg("+getCount()+")");
		} catch (JSException jse) {
			window.eval("alert("+jse+")");
		}		
	}

	public void incrementCounter() {
	    ctr++;
	}
	
	public String getCount(){
		return String.valueOf(ctr);
	}
	
	public void doWrite(){
	    String text = " Current Value Of Counter: " + (new Integer(ctr)).toString();
	    ctrLbl.setText(text);
	}
	
}
