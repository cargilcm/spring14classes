package P2PConnector;

public class MessageBoard {

	public void put(String msg) {
		// TODO Auto-generated method stub
		//test
		System.out.println("Message Received: " + msg + "\n");
	}

}
